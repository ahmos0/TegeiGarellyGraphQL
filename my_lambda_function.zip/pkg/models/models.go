package models

type Item struct {
	UUID     string
	WorkName string
	Author   string
	imageUrl string
	other    string
}
